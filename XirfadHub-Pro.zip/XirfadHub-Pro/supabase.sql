-- ================================================================
-- XirfadHub – Supabase database (ku orod SQL Editor ee Supabase)
-- ================================================================

-- 1) PASSWORD-KA ADMIN: BEDDEL qoraalkan ka hor intaadan orin! (dheer oo adag)
create table if not exists settings (key text primary key, value text not null);
insert into settings (key, value) values ('admin_password', 'PUT_A_LONG_PASSWORD_HERE')
  on conflict (key) do nothing;

-- 2) Shaxda
create table if not exists profiles (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null, phone text not null,
  skill text, city text, bio text, rate text,
  plan text not null default 'free', plan_until timestamptz,
  status text not null default 'pending'
);
create table if not exists jobs (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  title text not null, client text not null, phone text not null,
  budget text, category text, details text,
  status text not null default 'pending'
);
create table if not exists payments (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text, phone text not null, plan text not null,
  amount numeric, method text, txn text,
  status text not null default 'pending'
);

-- 3) Amniga (RLS): dadku way gelin karaan, laakiin ma akhrin karaan lambarrada
alter table settings enable row level security;
alter table profiles enable row level security;
alter table jobs enable row level security;
alter table payments enable row level security;

drop policy if exists "add profile" on profiles;
create policy "add profile" on profiles for insert to anon
  with check (plan = 'free' and plan_until is null and status = 'pending' and length(name) <= 60);
drop policy if exists "add job" on jobs;
create policy "add job" on jobs for insert to anon
  with check (status = 'pending' and length(title) <= 90);
drop policy if exists "add payment" on payments;
create policy "add payment" on payments for insert to anon
  with check (status = 'pending');

-- 4) Muuqaalka dadweynaha (lambarrada la qariyay)
create or replace view public_profiles as
  select id, created_at, name, skill, city, bio, rate, plan, plan_until
  from profiles where status = 'active';
create or replace view public_jobs as
  select id, created_at, title, client, budget, category, details
  from jobs where status = 'open';
grant select on public_profiles, public_jobs to anon;

-- 5) Hawlaha admin-ka (password-ka ayaa loo baahan yahay)
create or replace function admin_ok(p text) returns boolean
language sql security definer set search_path = public as $$
  select exists (select 1 from settings
    where key = 'admin_password' and value = p and value <> 'PUT_A_LONG_PASSWORD_HERE');
$$;

create or replace function admin_dump(p text) returns json
language plpgsql security definer set search_path = public as $$
begin
  if not admin_ok(p) then raise exception 'Password-ka waa khalad'; end if;
  return json_build_object(
    'profiles', (select coalesce(json_agg(x order by x.created_at desc), '[]'::json) from profiles x),
    'jobs',     (select coalesce(json_agg(x order by x.created_at desc), '[]'::json) from jobs x),
    'payments', (select coalesce(json_agg(x order by x.created_at desc), '[]'::json) from payments x));
end $$;

create or replace function admin_approve(p text, pay_id uuid, days int default 30) returns int
language plpgsql security definer set search_path = public as $$
declare pay payments; n int;
begin
  if not admin_ok(p) then raise exception 'Password-ka waa khalad'; end if;
  select * into pay from payments where id = pay_id;
  if not found then raise exception 'Lacag-bixinta lama helin'; end if;
  update payments set status = 'approved' where id = pay_id;
  update profiles
     set plan = pay.plan,
         plan_until = greatest(now(), coalesce(plan_until, now())) + make_interval(days => days)
   where phone = pay.phone;
  get diagnostics n = row_count;
  return n;
end $$;

create or replace function admin_reject(p text, pay_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not admin_ok(p) then raise exception 'Password-ka waa khalad'; end if;
  update payments set status = 'rejected' where id = pay_id;
end $$;

create or replace function admin_set_plan(p text, prof_id uuid, new_plan text, days int default 30) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not admin_ok(p) then raise exception 'Password-ka waa khalad'; end if;
  update profiles
     set plan = new_plan,
         plan_until = case when new_plan = 'free' then null else now() + make_interval(days => days) end
   where id = prof_id;
end $$;

create or replace function admin_set_status(p text, tbl text, rid uuid, st text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not admin_ok(p) then raise exception 'Password-ka waa khalad'; end if;
  if tbl = 'profiles' then
    update profiles set status = case when st = 'active' then 'active' else 'rejected' end where id = rid;
  elsif tbl = 'jobs' then
    update jobs set status = case when st in ('open','active') then 'open' else 'rejected' end where id = rid;
  else raise exception 'Shax aan jirin'; end if;
end $$;

create or replace function admin_delete(p text, tbl text, rid uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not admin_ok(p) then raise exception 'Password-ka waa khalad'; end if;
  if tbl = 'profiles' then delete from profiles where id = rid;
  elsif tbl = 'jobs' then delete from jobs where id = rid;
  elsif tbl = 'payments' then delete from payments where id = rid;
  else raise exception 'Shax aan jirin'; end if;
end $$;
