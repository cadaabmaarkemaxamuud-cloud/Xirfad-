/* Lakabka xogta: Supabase (dhab) ama localStorage (tijaabo) */
(function () {
  "use strict";
  var C = window.XH;
  var SB = !!(C.SUPABASE_URL && C.SUPABASE_KEY);
  var H = { apikey: C.SUPABASE_KEY, Authorization: "Bearer " + C.SUPABASE_KEY, "Content-Type": "application/json" };

  function uid() { return (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : Date.now() + "-" + Math.random().toString(16).slice(2); }
  function get(k) { try { return JSON.parse(localStorage.getItem("xh_" + k) || "[]"); } catch (_) { return []; } }
  function put(k, v) { try { localStorage.setItem("xh_" + k, JSON.stringify(v)); } catch (_) {} }

  function norm(p) {
    var d = String(p || "").replace(/\D/g, "");
    if (d.indexOf("00") === 0) d = d.slice(2);
    if (d.indexOf("252") === 0) return d;
    if (d.indexOf("0") === 0) d = d.slice(1);
    return "252" + d;
  }

  async function api(path, opt) {
    opt = opt || {};
    var r = await fetch(C.SUPABASE_URL.replace(/\/$/, "") + "/rest/v1/" + path,
      Object.assign({}, opt, { headers: Object.assign({}, H, opt.headers || {}) }));
    var t = await r.text();
    if (!r.ok) { var m = t; try { m = JSON.parse(t).message || t; } catch (_) {} throw new Error(m); }
    return t ? JSON.parse(t) : null;
  }
  function rpc(fn, args) { return api("rpc/" + fn, { method: "POST", body: JSON.stringify(args) }); }
  function insert(tbl, row) { return api(tbl, { method: "POST", headers: { Prefer: "return=minimal" }, body: JSON.stringify(row) }); }
  function chk(pw) { if (pw !== C.ADMIN_PASSWORD) throw new Error("Password-ka waa khalad"); }

  function seed() {
    if (SB || !C.SEED_DEMO) return;
    try { if (localStorage.getItem("xh_seeded")) return; } catch (_) { return; }
    var now = Date.now();
    function d(n) { return new Date(now + n * 864e5).toISOString(); }
    var i = 0;
    function mk(name, skill, city, rate, bio, plan) {
      i++;
      return { id: uid(), created_at: d(-i), name: name, phone: "25260000" + (1000 + i), skill: skill, city: city, rate: rate, bio: bio,
        plan: plan, plan_until: plan === "free" ? null : d(25), status: "active", demo: true };
    }
    put("profiles", [
      mk("Axmed C.", "Naqshad", "Muqdisho", "$15/mashruuc", "Logo, branding iyo poster-ro casri ah. 5+ sano khibrad.", "elite"),
      mk("Hodan M.", "Barnaamij & Web", "Hargeysa", "$25/saacad", "Websites iyo apps dhisa – React, Node, WordPress.", "platinum"),
      mk("Faduma H.", "Social Media", "Muqdisho", "$80/bil", "Maamulka bogagga ganacsiga: Facebook, TikTok, Instagram.", "diamond"),
      mk("Cabdi R.", "Video & Animation", "Garowe", "$30/muuqaal", "Video-yo xayeysiis iyo edit TikTok/YouTube.", "gold"),
      mk("Sagal A.", "Qorid & Tarjumaad", "Muqdisho", "$0.05/erey", "Tarjumaad Ingiriisi ↔ Soomaali iyo qorid maqaallo.", "silver"),
      mk("Maxamed K.", "Tacliin & Tababar", "Kismaayo", "$10/saacad", "Macallin xisaab iyo Ingiriisi, online.", "bronze"),
      mk("Ifraax Y.", "Xisaabaad & Maaliyad", "Baydhabo", "$12/saacad", "Buug-haynta xisaabaadka iyo warbixinno.", "free"),
      mk("Yuusuf S.", "Caawimaad Macaamiisha", "Beledweyne", "$6/saacad", "Jawaabista macaamiisha WhatsApp & call.", "free")
    ]);
    put("jobs", [
      { id: uid(), created_at: d(-0.2), title: "Logo cusub oo ganacsi makhaayad ah", client: "Makhaayadda Tusaale", phone: "252600009001", budget: "$40", category: "Naqshad", details: "Waxaan u baahanahay logo iyo midabo.", status: "open", demo: true },
      { id: uid(), created_at: d(-1), title: "Website dukaan online ah", client: "Dukaan Tusaale", phone: "252600009002", budget: "$250", category: "Barnaamij & Web", details: "Dukaan yar oo alaabta lagu iibiyo, lacag-bixin EVC.", status: "open", demo: true },
      { id: uid(), created_at: d(-2), title: "Tarjumaad dukumeenti 10 bog ah", client: "Shirkad Tusaale", phone: "252600009003", budget: "$30", category: "Qorid & Tarjumaad", details: "Ingiriisi → Soomaali.", status: "open", demo: true }
    ]);
    put("payments", []);
    try { localStorage.setItem("xh_seeded", "1"); } catch (_) {}
  }
  seed();

  // Haddii xog tusaale ah horey u jirtay browser-ka, ka saar (marka SEED_DEMO=false)
  if (!SB && !C.SEED_DEMO) {
    ["profiles", "jobs"].forEach(function (k) {
      var a = get(k), b = a.filter(function (x) { return !x.demo; });
      if (b.length !== a.length) put(k, b);
    });
  }

  window.XHDB = {
    mode: SB ? "supabase" : "demo",
    norm: norm,

    publicProfiles: async function () {
      if (SB) return api("public_profiles?select=*&order=created_at.desc");
      return get("profiles").filter(function (p) { return p.status === "active"; }).map(function (p) { var c = Object.assign({}, p); delete c.phone; return c; });
    },
    publicJobs: async function () {
      if (SB) return api("public_jobs?select=*&order=created_at.desc");
      return get("jobs").filter(function (j) { return j.status === "open"; }).map(function (j) { var c = Object.assign({}, j); delete c.phone; return c; });
    },

    addProfile: async function (o) {
      var row = Object.assign({ plan: "free", plan_until: null, status: "pending" }, o, { phone: norm(o.phone) });
      if (SB) return insert("profiles", row);
      row.id = uid(); row.created_at = new Date().toISOString();
      put("profiles", get("profiles").concat([row]));
    },
    addJob: async function (o) {
      var row = Object.assign({ status: "pending" }, o, { phone: norm(o.phone) });
      if (SB) return insert("jobs", row);
      row.id = uid(); row.created_at = new Date().toISOString();
      put("jobs", get("jobs").concat([row]));
    },
    addPayment: async function (o) {
      var row = Object.assign({ status: "pending" }, o, { phone: norm(o.phone) });
      if (SB) return insert("payments", row);
      row.id = uid(); row.created_at = new Date().toISOString();
      put("payments", get("payments").concat([row]));
    },

    /* ---- Admin ---- */
    adminDump: async function (pw) {
      if (SB) return rpc("admin_dump", { p: pw });
      chk(pw);
      return { profiles: get("profiles").reverse(), jobs: get("jobs").reverse(), payments: get("payments").reverse() };
    },
    adminApprove: async function (pw, id) {
      if (SB) return rpc("admin_approve", { p: pw, pay_id: id, days: C.PLAN_DAYS });
      chk(pw);
      var pays = get("payments"), p = pays.find(function (x) { return x.id === id; });
      if (!p) throw new Error("Lacag-bixinta lama helin");
      p.status = "approved"; put("payments", pays);
      var pr = get("profiles"), n = 0;
      pr.forEach(function (r) {
        if (r.phone === p.phone) {
          var base = Math.max(Date.now(), r.plan_until ? +new Date(r.plan_until) : 0);
          r.plan = p.plan; r.plan_until = new Date(base + C.PLAN_DAYS * 864e5).toISOString(); n++;
        }
      });
      put("profiles", pr); return n;
    },
    adminReject: async function (pw, id) {
      if (SB) return rpc("admin_reject", { p: pw, pay_id: id });
      chk(pw);
      var pays = get("payments"), p = pays.find(function (x) { return x.id === id; });
      if (p) { p.status = "rejected"; put("payments", pays); }
    },
    adminSetStatus: async function (pw, tbl, id, st) {
      if (SB) return rpc("admin_set_status", { p: pw, tbl: tbl, rid: id, st: st });
      chk(pw);
      if (["profiles", "jobs"].indexOf(tbl) < 0) return;
      var a = get(tbl), r = a.find(function (x) { return x.id === id; });
      if (r) { r.status = st; put(tbl, a); }
    },
    adminSetPlan: async function (pw, id, plan, days) {
      if (SB) return rpc("admin_set_plan", { p: pw, prof_id: id, new_plan: plan, days: days });
      chk(pw);
      var pr = get("profiles"), r = pr.find(function (x) { return x.id === id; });
      if (r) { r.plan = plan; r.plan_until = plan === "free" ? null : new Date(Date.now() + days * 864e5).toISOString(); put("profiles", pr); }
    },
    adminDelete: async function (pw, tbl, id) {
      if (SB) return rpc("admin_delete", { p: pw, tbl: tbl, rid: id });
      chk(pw);
      if (["profiles", "jobs", "payments"].indexOf(tbl) < 0) return;
      put(tbl, get(tbl).filter(function (x) { return x.id !== id; }));
    }
  };
})();
