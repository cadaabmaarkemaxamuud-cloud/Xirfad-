/* ============ XIRFADHUB – SETTINGS (halkan wax walba ka beddel) ============ */
window.XH = {
  SITE: "XirfadHub",
  DEVELOPER: "Sharmake",

  // Lambarka WhatsApp ee fariimaha oo dhan lagu helo (code dalka la socda, + la'aan)
  WHATSAPP: "252905202482",

  // Habka lacag-bixinta. Mid walba lambar u gaar ah. Lambarku waa inuu ka diiwaangashan yahay shabakaddaas.
  // Haddii aadan lambar ku lahayn shabakad (tus. Zaad), tirtir xariiqdaas.
  PAY_NAME: "",   // magaca akoonka (ikhtiyaari), tus. "Sharmake ..."
  PAY_METHODS: [
    { id: "sahal",  name: "Sahal",       number: "252905202482" },
    { id: "evc",    name: "EVC Plus",    number: "252905202482" },
    { id: "edahab", name: "eDahab",      number: "252905202482" },
    { id: "zaad",   name: "Zaad",        number: "252905202482" },
    { id: "other",  name: "Kale (Premier Wallet, bank...)", number: "252905202482" }
  ],

  PLAN_DAYS: 30,   // muddada premium-ka (maalmo)

  // Database dhab ah (Supabase). Ka tag README.md. Haddii la madhan yahay = nooc tijaabo ah (browser-ka kaliya).
  SUPABASE_URL: "",
  SUPABASE_KEY: "",

  // Password-ka admin ee noocan tijaabada ah. Marka Supabase la isticmaalo, password-ka waxaa lagu dhejiyaa database-ka (SQL).
  ADMIN_PASSWORD: "DEVELOPER220",

  // Xog tusaale ah (calaamadaysan "TUSAALE"). U dhig false marka aad bilowdo dhabta.
  SEED_DEMO: false,

  CATEGORIES: ["Naqshad", "Barnaamij & Web", "Qorid & Tarjumaad", "Social Media", "Video & Animation", "Tacliin & Tababar", "Xisaabaad & Maaliyad", "Caawimaad Macaamiisha", "Kale"],

  // Xirmooyinka premium. rank = heerka (sare = ka horreeya liiska). tick = calaamad buluug ah.
  PLANS: [
    { id: "bronze",   name: "Bronze",   icon: "🥉", price: 2,  rank: 1, color: "#cd7f32", tick: false,
      perks: ["Calaamad Bronze profile-kaaga", "Ka horreeya profile-yada bilaashka ah"] },
    { id: "silver",   name: "Silver",   icon: "🥈", price: 5,  rank: 2, color: "#8b9bb4", tick: true,
      perks: ["Calaamad buluug ah ✓ (Verified)", "Silver frame", "Ka horreeya Bronze"] },
    { id: "gold",     name: "Gold",     icon: "🥇", price: 7,  rank: 3, color: "#f59e0b", tick: true,
      perks: ["Calaamad buluug ah ✓", "Gold frame oo dhalaalaya", "Ka horreeya Silver"] },
    { id: "platinum", name: "Platinum", icon: "💠", price: 10, rank: 4, color: "#06b6d4", tick: true, hot: true,
      perks: ["Calaamad buluug ah ✓", "Ka muuqda 'La soo bandhigay' bogga hore", "Ka horreeya Gold"] },
    { id: "diamond",  name: "Diamond",  icon: "💎", price: 13, rank: 5, color: "#8b5cf6", tick: true,
      perks: ["Calaamad buluug ah ✓", "Bogga hore + raadinta ugu sarreeya", "Taageero WhatsApp oo degdeg ah"] },
    { id: "elite",    name: "Elite",    icon: "👑", price: 15, rank: 6, color: "#ef4444", tick: true,
      perks: ["Calaamad buluug ah ✓ + taaj 👑", "Had iyo jeer #1 (pinned)", "Bogga hore ee ugu weyn", "Taageero WhatsApp oo degdeg ah"] }
  ]
};
