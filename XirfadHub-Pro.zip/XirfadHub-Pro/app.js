(function () {
  "use strict";
  var C = window.XH, DB = window.XHDB;
  function $(s) { return document.querySelector(s); }
  function $$(s) { return Array.prototype.slice.call(document.querySelectorAll(s)); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }

  var PLANS = {}; C.PLANS.forEach(function (p) { PLANS[p.id] = p; });
  function eff(p) { var pl = PLANS[p.plan]; return (pl && p.plan_until && new Date(p.plan_until) > new Date()) ? pl : null; }
  function rank(p) { var e = eff(p); return e ? e.rank : 0; }
  function wa(t) { return "https://wa.me/" + C.WHATSAPP + "?text=" + encodeURIComponent(t); }

  var TICK = '<svg class="tick" viewBox="0 0 24 24" aria-label="Verified"><title>Verified</title><path fill="currentColor" d="M12 1.6l2.5 1.8 3.1-.2 1 2.9 2.6 1.8-.9 3 .9 3-2.6 1.8-1 2.9-3.1-.2L12 22.4l-2.5-1.8-3.1.2-1-2.9-2.6-1.8.9-3-.9-3 2.6-1.8 1-2.9 3.1.2z"/><path fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" d="M8 12.2l2.8 2.8 5.2-5.4"/></svg>';

  function ago(iso) {
    var s = (Date.now() - new Date(iso)) / 1000;
    if (s < 90) return "hadda";
    if (s < 3600) return Math.round(s / 60) + " daqiiqo kahor";
    if (s < 86400) return Math.round(s / 3600) + " saac kahor";
    return Math.round(s / 86400) + " maalmood kahor";
  }
  var tt;
  function toast(m) { var t = $("#toast"); t.textContent = m; t.classList.add("show"); clearTimeout(tt); tt = setTimeout(function () { t.classList.remove("show"); }, 3800); }

  /* ---------- theme / menu ---------- */
  $("#theme").onclick = function () {
    var d = document.documentElement, n = d.dataset.theme === "dark" ? "light" : "dark";
    d.dataset.theme = n; try { localStorage.setItem("xh_theme", n); } catch (_) {}
  };
  $("#burger").onclick = function () { $("#links").classList.toggle("open"); };
  $$("#links a").forEach(function (a) { a.addEventListener("click", function () { $("#links").classList.remove("open"); }); });
  $("#yr").textContent = new Date().getFullYear();
  $("#wa").href = "https://wa.me/" + C.WHATSAPP;
  $("#pdays").textContent = C.PLAN_DAYS;

  /* ---------- state ---------- */
  var PROF = [], JOBS = [], cat = "", q = "";

  function card(p) {
    var e = eff(p), tick = e && e.tick;
    var ini = p.name.split(/\s+/).map(function (w) { return w[0] || ""; }).slice(0, 2).join("").toUpperCase();
    var hue = Array.prototype.reduce.call(p.name, function (a, c) { return a + c.charCodeAt(0); }, 0) % 360;
    var msg = "Asc, waxaan rabaa inaan la xiriiro shaqaalaha: " + p.name + " (" + p.skill + ") – ID " + String(p.id).slice(0, 6);
    return '<article class="wcard' + (e ? " t-" + e.id : "") + '"' + (e ? ' style="--tc:' + e.color + '"' : "") + ">" +
      (e ? '<span class="tier" style="background:' + e.color + '">' + e.icon + " " + esc(e.name) + "</span>" : "") +
      (p.demo ? '<span class="demo">TUSAALE</span>' : "") +
      '<div class="av" style="background:hsl(' + hue + ' 55% 42%)">' + esc(ini) + "</div>" +
      "<h3>" + esc(p.name) + (tick ? TICK : "") + "</h3>" +
      '<p class="sk">' + esc(p.skill) + (p.city ? " · " + esc(p.city) : "") + "</p>" +
      '<p class="bio">' + esc(p.bio || "") + "</p>" +
      '<div class="row"><b>' + esc(p.rate || "") + '</b><a class="btn sm" target="_blank" rel="noopener" href="' + wa(msg) + '">La xiriir</a></div></article>';
  }

  function renderWorkers() {
    var list = PROF.slice().sort(function (a, b) { return rank(b) - rank(a) || new Date(b.created_at) - new Date(a.created_at); });
    var feat = list.filter(function (p) { return rank(p) >= 4; }).slice(0, 6);
    $("#featbox").classList.toggle("hidden", !feat.length);
    $("#featured").innerHTML = feat.map(card).join("");
    var ql = q.toLowerCase();
    var f = list.filter(function (p) {
      return (!cat || p.skill === cat) && (!ql || (p.name + " " + p.skill + " " + (p.city || "") + " " + (p.bio || "")).toLowerCase().indexOf(ql) >= 0);
    });
    $("#workers").innerHTML = f.length ? f.map(card).join("") :
      '<div class="empty" style="grid-column:1/-1">Shaqaale lama helin. <a href="#kubiir" style="color:var(--p);font-weight:700">Noqo kan ugu horreeya →</a></div>';
  }

  function renderJobs() {
    var list = JOBS.slice().sort(function (a, b) { return new Date(b.created_at) - new Date(a.created_at); });
    $("#jobs").innerHTML = list.length ? list.map(function (j) {
      var first = String(j.client || "").split(/\s+/)[0];
      var msg = "Asc, waxaan rabaa inaan codsado shaqada: " + j.title + " (" + (j.budget || "-") + ") – ID " + String(j.id).slice(0, 6);
      return '<article class="jcard"><div style="flex:1;min-width:220px"><span class="cat">' + esc(j.category) + "</span>" +
        (j.demo ? ' <span class="demo" style="position:static">TUSAALE</span>' : "") +
        "<h3>" + esc(j.title) + "</h3><p>" + esc(j.details || "") + "</p><small>" + esc(first) + " · " + ago(j.created_at) + "</small></div>" +
        '<div class="jr"><b>' + esc(j.budget || "") + '</b><a class="btn sm" target="_blank" rel="noopener" href="' + wa(msg) + '">Codso / La xiriir</a></div></article>';
    }).join("") : '<div class="empty">Weli shaqo ma jirto. <a href="#kubiir" style="color:var(--p);font-weight:700">Soo dhig shaqo →</a></div>';
  }

  function renderStats() {
    $(".stats").classList.toggle("hidden", !PROF.length && !JOBS.length);
    $("#s-w").textContent = PROF.length;
    $("#s-j").textContent = JOBS.length;
    $("#s-p").textContent = PROF.filter(function (p) { var e = eff(p); return e && e.tick; }).length;
  }

  function renderCats() {
    var all = [""].concat(C.CATEGORIES);
    $("#cats").innerHTML = all.map(function (c) { return '<button class="chip' + (c === cat ? " on" : "") + '" data-c="' + esc(c) + '">' + (c || "Dhammaan") + "</button>"; }).join("");
    $("#w-skill").innerHTML = '<option value="">Dooro xirfadaada</option>' + C.CATEGORIES.map(function (c) { return "<option>" + esc(c) + "</option>"; }).join("");
    $("#m-cat").innerHTML = '<option value="">Nooca shaqada</option>' + C.CATEGORIES.map(function (c) { return "<option>" + esc(c) + "</option>"; }).join("");
  }
  $("#cats").addEventListener("click", function (e) {
    var b = e.target.closest(".chip"); if (!b) return;
    cat = b.dataset.c; renderCats(); renderWorkers();
  });

  $("#hsearch").addEventListener("submit", function (e) {
    e.preventDefault(); q = $("#hq").value.trim(); renderWorkers();
    document.getElementById("shaqaale").scrollIntoView({ behavior: "smooth" });
  });

  function renderPlans() {
    $("#plans").innerHTML = C.PLANS.map(function (p) {
      return '<div class="plan' + (p.hot ? " hot" : "") + '" style="--tc:' + p.color + '">' + (p.hot ? '<span class="ribbon">Ugu caansan</span>' : "") +
        "<h3><span>" + p.icon + "</span> " + esc(p.name) + (p.tick ? TICK : "") + "</h3>" +
        '<div class="price">$' + p.price + "<small>/" + C.PLAN_DAYS + " maalmood</small></div><ul>" +
        p.perks.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") +
        '</ul><button class="btn wide" data-plan="' + p.id + '">Iibso ' + esc(p.name) + "</button></div>";
    }).join("");
  }
  $("#plans").addEventListener("click", function (e) { var b = e.target.closest("[data-plan]"); if (b) payModal(b.dataset.plan); });

  /* ---------- modal ---------- */
  function openModal(html) { $("#modal .mbody").innerHTML = html; $("#modal").classList.add("open"); document.body.style.overflow = "hidden"; }
  function closeModal() { $("#modal").classList.remove("open"); document.body.style.overflow = ""; }
  $("#mclose").onclick = closeModal;
  $("#modal").addEventListener("click", function (e) { if (e.target.id === "modal") closeModal(); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeModal(); });

  function payModal(id) {
    var pl = PLANS[id], mi = 0;
    openModal(
      '<h3 style="margin-bottom:4px">' + pl.icon + " " + esc(pl.name) + " – $" + pl.price + "/" + C.PLAN_DAYS + " maalmood</h3>" +
      '<p class="mut" style="margin-bottom:6px;font-size:.9rem">1) Dooro habka lacag-bixinta</p>' +
      '<div class="mchips" id="mm">' + C.PAY_METHODS.map(function (m, i) { return '<button type="button" class="mc' + (i ? "" : " on") + '" data-i="' + i + '">' + esc(m.name) + "</button>"; }).join("") + "</div>" +
      '<div class="paybox"><span>Dir <b>$' + pl.price + '</b> lambarkan:</span><div class="num" id="pnum"></div>' +
      (C.PAY_NAME ? "<small>Magaca: " + esc(C.PAY_NAME) + "</small>" : "") +
      '<button type="button" class="btn sm ghost" id="pcopy" style="align-self:flex-start">Koobi lambarka</button></div>' +
      '<p class="mut" style="margin-bottom:8px;font-size:.9rem">2) Kadib buuxi xogtan si loo xaqiijiyo</p>' +
      '<form id="payf" class="form" style="padding:0;border:0;background:none">' +
      '<input name="name" placeholder="Magacaaga" required maxlength="60">' +
      '<input name="phone" placeholder="Lambarka profile-kaaga (kan aad ku diiwaangelisay)" required inputmode="tel" maxlength="20">' +
      '<input name="txn" placeholder="Koodhka kala wareejinta (Transaction ID)" required maxlength="40">' +
      '<button class="btn wide" type="submit">Waan bixiyay – xaqiiji</button></form>'
    );
    function showNum() { $("#pnum").textContent = "+" + C.PAY_METHODS[mi].number; }
    showNum();
    $("#mm").onclick = function (e) {
      var b = e.target.closest(".mc"); if (!b) return;
      mi = +b.dataset.i; $$("#mm .mc").forEach(function (x) { x.classList.remove("on"); }); b.classList.add("on"); showNum();
    };
    $("#pcopy").onclick = function () {
      var n = C.PAY_METHODS[mi].number;
      if (navigator.clipboard) navigator.clipboard.writeText("+" + n).then(function () { toast("Lambarka waa la koobiyay"); }, function () { toast("+" + n); });
      else toast("+" + n);
    };
    $("#payf").onsubmit = async function (e) {
      e.preventDefault();
      var f = e.target, d = Object.fromEntries(new FormData(f).entries()), btn = f.querySelector("button");
      btn.disabled = true;
      var m = C.PAY_METHODS[mi];
      try {
        await DB.addPayment({ name: d.name, phone: d.phone, plan: pl.id, amount: pl.price, method: m.name, txn: d.txn });
      } catch (err) { btn.disabled = false; toast("Khalad: " + err.message); return; }
      var msg = "Asc! Waxaan bixiyay premium.\nXirmo: " + pl.name + " ($" + pl.price + ")\nHab: " + m.name + "\nKoodh: " + d.txn + "\nMagac: " + d.name + "\nLambar: " + d.phone + "\nFadlan xaqiiji.";
      openModal('<div style="text-align:center"><div style="font-size:3rem">✅</div><h3>Mahadsanid!</h3>' +
        '<p class="mut" style="margin:10px 0 18px">Codsigaaga waa la helay. Si degdeg ah loo xaqiijiyo, guji badhanka hoose oo fariinta ugu dir WhatsApp. Marka la xaqiijiyo, <b>' + esc(pl.name) + "</b> wuu shaqaynayaa.</p>" +
        '<a class="btn wide" target="_blank" rel="noopener" href="' + wa(msg) + '">Ku wargeli WhatsApp</a></div>');
    };
  }

  /* ---------- forms ---------- */
  $$(".tab").forEach(function (t) {
    t.onclick = function () {
      $$(".tab").forEach(function (x) { x.classList.remove("on"); }); t.classList.add("on");
      $("#form-w").classList.toggle("hidden", t.dataset.t !== "w");
      $("#form-m").classList.toggle("hidden", t.dataset.t !== "m");
    };
  });

  function successModal(t, msg) {
    openModal('<div style="text-align:center"><div style="font-size:3rem">✅</div><h3>' + esc(t) + '</h3>' +
      '<p class="mut" style="margin:10px 0 18px">Si degdeg loo aqbalo, guji badhanka hoose oo fariinta ugu dir WhatsApp.</p>' +
      '<a class="btn wide" target="_blank" rel="noopener" href="' + wa(msg) + '">Ku wargeli WhatsApp</a></div>');
  }
  function bind(id, fn, okMsg, waMsg) {
    $(id).addEventListener("submit", async function (e) {
      e.preventDefault();
      var f = e.target, d = Object.fromEntries(new FormData(f).entries());
      if (d.website) return; // honeypot
      delete d.website;
      var btn = f.querySelector("button[type=submit]"); btn.disabled = true;
      try { await fn(d); f.reset(); successModal(okMsg, waMsg(d)); await load(); }
      catch (err) { toast("Khalad: " + err.message); }
      btn.disabled = false;
    });
  }
  bind("#form-w", function (d) { return DB.addProfile({ name: d.name, phone: d.phone, skill: d.skill, city: d.city, rate: d.rate, bio: d.bio }); },
    "Profile-kaaga waa la helay! Wuxuu muuqan doonaa marka la aqbalo.", function (d) { return "Asc! Waxaan diiwaangeliyay profile.\nMagac: " + d.name + "\nXirfad: " + d.skill + "\nLambar: " + d.phone + "\nFadlan aqbal."; });
  bind("#form-m", function (d) { return DB.addJob({ client: d.client, phone: d.phone, title: d.title, category: d.category, budget: d.budget, details: d.details }); },
    "Shaqadaada waa la helay! Waxay muuqan doontaa marka la aqbalo.", function (d) { return "Asc! Waxaan soo dhigay shaqo.\nShaqo: " + d.title + "\nMiisaaniyad: " + (d.budget || "-") + "\nMagac: " + d.client + "\nLambar: " + d.phone + "\nFadlan aqbal."; });

  /* ---------- load ---------- */
  async function load() {
    try {
      var r = await Promise.all([DB.publicProfiles(), DB.publicJobs()]);
      PROF = r[0] || []; JOBS = r[1] || [];
    } catch (err) { toast("Xogta lama soo qaadi karin"); }
    renderStats(); renderWorkers(); renderJobs();
  }

  /* scroll reveal */
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }); }, { threshold: .12 });
    $$(".reveal").forEach(function (el) { io.observe(el); });
  } else { $$(".reveal").forEach(function (el) { el.classList.add("in"); }); }

  renderCats(); renderPlans(); load();
  try { console.log("%cWeb by Developer Sharmake", "color:#1d4ed8;font-weight:bold"); } catch (_) {}
})();
