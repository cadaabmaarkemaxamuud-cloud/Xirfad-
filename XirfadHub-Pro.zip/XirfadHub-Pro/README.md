# XirfadHub Pro – Web by Developer Sharmake

## Faylasha
- `index.html` – website-ka dadweynaha (shaqaale, shaqooyin, premium, ku biir)
- `admin.html` – dashboard (lacag-bixin, shaqaale, shaqooyin)
- `config.js` – **halkan wax walba ka beddel** (lambar, xirmooyin, qiimaha, password)
- `db.js`, `app.js`, `style.css` – koodhka
- `supabase.sql` – database dhab ah

## Noocyada
**1. Tijaabo (hadda, Supabase la'aan):** website-ku wuu shaqeeyaa, laakiin xogta qof walba waxay ku kaydsan tahay browser-kiisa. Fariimaha WhatsApp-ka ayaa adiga kuu imanaya. Xogta "TUSAALE" waa been-abuur muuqaal ah (`SEED_DEMO:false` si aad u damiso).

**2. Dhab ah (Supabase, bilaash):**
1. Samee akoon **supabase.com** → New project.
2. SQL Editor → ku dheji `supabase.sql`, **laakiin marka hore beddel** `PUT_A_LONG_PASSWORD_HERE` password dheer oo adag (kaasi waa password-ka admin).
3. Settings → API → koobi **Project URL** iyo **anon public key** → ku dheji `config.js` (`SUPABASE_URL`, `SUPABASE_KEY`).
4. Ku dhig Netlify Drop (app.netlify.com/drop).

Hadda diiwaangelinta qof walba waxay gashaa database-ka, `admin.html` ayaa dhammaantood tusaya, lambarrada dadkuna dadweynaha lagama arko.

## Lacag-bixinta (sida ay u shaqeyso)
Macmiilku wuxuu u dirayaa lacagta lambarkaaga (Sahal/EVC/eDahab/Zaad), geliyaa koodhka kala wareejinta → fariin WhatsApp ah ayaa kuu imanaysa + waxay ka muuqataa **Admin → Lacag-bixin**. Waxaad hubisaa lacagta telefoonkaaga, guji **Aqbal ✓** → premium-kaas wuu shaqaynayaa 30 maalmood. (Xaqiijinta toos ah ee aan gacan laheyn waxay u baahan tahay merchant API sida WaafiPay.)

Xusuus: lambarkaaga waa inuu ka diiwaangashan yahay shabakad kasta oo aad liiska ku haysid (`PAY_METHODS` ee `config.js`).
